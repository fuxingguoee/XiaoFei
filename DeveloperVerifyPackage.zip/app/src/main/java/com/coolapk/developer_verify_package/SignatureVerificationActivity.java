package com.coolapk.developer_verify_package;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SignatureVerificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signature_verification);
    }
}
